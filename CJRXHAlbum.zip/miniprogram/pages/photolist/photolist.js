var util = require('../../utils/util.js');
var th = require('../../utils/throttle/throttle.js');
// pages/photolist/photolist.js
const app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    openId: null,
    pageIndex: 1,
    pageSize: 5,
    pageCount: 0,
    total: 0,
    uploadDocList: [],
    onLike: null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    if (app.globalData.openId) {
      //全局应用已有openId
      this.setData({
        openId: app.globalData.openId
      });
    } else {
      // 由于 login云函数 是网络请求，可能会在 Page.onLoad 之后才返回 
      // 所以此处加入 callback 以防止这种情况 
      app.openIdReadyCallback = res => {
        this.setData({
          openId: res.result.openid
        })
      }
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    let that = this;
    const db = wx.cloud.database();
    db.collection("uploadDoc").count({
      success: function(res) {
        console.log("获取记录列表总数成功" + res.total);
        if (that.data.total != res.total) {
          //如果有数据刷新，重新加载第一页
          that.data.pageIndex = 1;
          that.fetchUploadDocList("刷新中");
        }
      }
    });
  },

  onPullDownRefresh: function() {
    //下拉刷新记录列表
    this.data.pageIndex = 1;
    this.fetchUploadDocList("刷新中");
    //停止下拉刷新
    wx.stopPullDownRefresh();
  },
  onReachBottom: function() {
    if (this.data.pageIndex < this.data.pageCount) {
      //如果没到最后一页，页码加1，并加载新的一页记录列表数据
      this.data.pageIndex = this.data.pageIndex + 1;
      this.fetchUploadDocList("加载中");
    } else {
      util.showTip('没有更多记录了');
    }
    console.log(this.data.pageIndex)
  },
  fetchUploadDocList: function(title) {
    let that = this;
    let pageIndex = that.data.pageIndex;
    let pageSize = that.data.pageSize;
    const db = wx.cloud.database();
    //先计算总数，才可以进行分页
    db.collection("uploadDoc").count({
      success: function(res) {
        console.log("获取记录列表总数成功" + res.total);
        let pageCount = Math.ceil(res.total / pageSize);
        let total = res.total;
        //根据不同需求的抓取显示不同的进程提示
        wx.showLoading({
          title: title,
          mask: true
        });
        //分页获取记录列表内容
        db.collection("uploadDoc").skip((pageIndex - 1) * pageSize).limit(pageSize).orderBy('time', 'desc').get({
          success: function(res) {
            console.log("获取记录列表成功");
            //先获取原先的记录列表
            let tempList = that.data.uploadDocList;
            if (that.data.pageIndex == 1) {
              //如果要显示第一页，无需拼接记录列表数据
              tempList = res.data;
            } else {
              //否则，拼接新的记录列表数据
              tempList = tempList.concat(res.data);
            }
            //更新数据
            that.setData({
              pageCount: pageCount,
              total: total,
              uploadDocList: tempList
            });
            //获取新纪录点赞状态
            that.getOnLike(0, res.data.length, res.data);
          },
          fail: function(res) {
            console.log("获取记录列表失败");
          }
        });
      },
      fail: function(res) {
        console.log("获取记录列表总数失败");
      }
    });
  },
  getOnLike: function(index, length, newDoc) {
    let that = this;
    let openId = this.data.openId;
    let id = newDoc[index]._id;
    const db = wx.cloud.database();
    db.collection("praiseDoc").where({
      clickUserId: openId,
      recordId: id
    }).count({
      success: function(res) {
        if (res.total != 0) {
          //添加喜欢键值对id:true
          let state = "onLike." + id;
          that.setData({
            [state]: true
          });
        } else {
          console.log("用户不喜欢");
          //添加不喜欢键值对id:false
          let state = "onLike." + id;
          that.setData({
            [state]: false
          });
        }
      },
      fail: function(res) {
        //获取失败,默认是不喜欢
        console.log("默认用户不喜欢");
        //添加不喜欢键值对id:true
        let state = "onLike." + id;
        that.setData({
          [state]: false
        });
      },
      complete: function(res) {
        if ((index + 1) == length) {
          //最后一个记录判断当前用户是否喜欢完成
          wx.hideLoading();
        } else {
          //否则，判断下一个记录
          index = index + 1;
          that.getOnLike(index, length, newDoc);
        }
      }
    });
  },
  deleteUploadDoc: function(event) {
    let that = this;
    //询问用户是否删除
    wx.showModal({
      title: '提示',
      content: '确定要删除记录吗？',
      success: function(res) {
        if (res.confirm) {
          //确定删除
          wx.showLoading({
            title: '删除中',
          });
          //获得记录在数据库的id
          let id = event.target.dataset.id;
          const db = wx.cloud.database();
          //从数据库删除该记录
          db.collection('uploadDoc').doc(id).remove({
            success: function(res) {
              console.log("删除记录成功");
              //删除praiseDoc表中的关于这条的所有点赞的用户
              that.deletePraiseDoc(id);
              //获得图片数组在存储的fileId，先获取imageurl
              let imageUrls = event.target.dataset.imageurls;
              for (let i = 0; i < imageUrls.length; i++) {
                let fileId = util.getFileId(imageUrls[i]);
                //从存储真正删除该图片
                wx.cloud.deleteFile({
                  fileList: [fileId],
                  success: function(res) {
                    console.log("删除照片成功");
                  },
                  fail: function(res) {
                    console.log("删除照片失败");
                  }
                });
              }
              //根据id更新图片列表
              that.updateImages(id);
            },
            fail: function(res) {
              console.log("删除照片记录失败");
            },
            complete: function(res) {
              wx.hideLoading();
            }
          });
        }
      }
    });
  },

  deletePraiseDoc: function(recordId) {
    console.log(recordId);
    wx.cloud.callFunction({
      // 要调用的云函数名称
      name: 'praiseOperate',
      // 传递给云函数的event参数
      
      data: {
        recordId: recordId,
        operate: 'removeall'
      }
    }).then(res => {
      // output: res.result === 3
    }).catch(err => {
      // handle error
    })
  },

  updateImages: function(id) {
    let that = this;
    //删除后更新记录列表
    let list = that.data.uploadDocList;
    let uploadDocList = null;
    //去掉删除的
    for (let i = 0; i < list.length; i++) {
      if (list[i]._id == id) {
        list.splice(i, 1);
        uploadDocList = list;
        break;
      }
    }
    //加载一条新记录加入当前记录列表
    let pageIndex = that.data.pageIndex;
    let pageSize = that.data.pageSize;
    const db = wx.cloud.database();
    //更新总数，页数，还有记录列表
    db.collection("uploadDoc").count({
      success: function(res) {
        console.log("获取记录列表总数成功" + res.total);
        let pageCount = Math.ceil(res.total / pageSize);
        let total = res.total;
        if ((uploadDocList.length + 1) <= res.total) {
          //如果还有未加载数据，则从数据库取一条数据补充当前页
          //根据不同需求的抓取显示不同的进程提示
          wx.showLoading({
            title: '刷新中',
          });
          //分页获取记录列表内容，因为是当前页补充一条新数据，所以跳过pageIndex * pageSize - 1条
          db.collection("uploadDoc").skip(pageIndex * pageSize - 1).limit(1).orderBy('time', 'desc').get({
            success: function(res) {
              console.log("获取记录列表成功");
              //把获得的新数据加到尾部
              uploadDocList = uploadDocList.concat(res.data);
              //更新数据
              that.setData({
                pageCount: pageCount,
                total: total,
                uploadDocList: uploadDocList
              });
            },
            fail: function(res) {
              console.log("获取记录列表失败");
            },
            complete: function(res) {
              wx.hideLoading();
            }
          });
        } else {
          //没有还未加载数据
          that.setData({
            pageCount: pageCount,
            total: total,
            uploadDocList: uploadDocList
          });
        }
      },
      fail: function(res) {
        console.log("获取记录列表总数失败");
      }
    });
  },
  gotoUploadPhoto: function() {
    //跳转到上传页面
    wx.navigateTo({
      url: '../uploadphoto/uploadphoto',
    });
  },

  //图片预览
  previewImg: function(event) {
    const imgurls = event.target.dataset.imgeurls;
    const currentphoto = event.target.dataset.photo;
    wx.previewImage({
      current: currentphoto, // 当前显示图片的http链接
      urls: imgurls // 需要预览的图片http链接列表
    })
  },

  /**
   * 点赞响应事件(已添加节流函数，防止恶意点击)
   */
  onlike: th.throttle(function (that,event) {
    //点赞获取点赞者的openid和记录的id和点赞数
    let localopenid = app.globalData.openId;
    let _id = event.target.dataset.id;
    let tempList = that.data.uploadDocList;
    let state = "onLike." + _id;
    let i;
    let flag;
    for (i = 0; i < tempList.length; i++) {
      if (_id == tempList[i]._id) {
        break;
      }
    }
    if (!that.data.onLike[_id]) { //点赞
      tempList[i].praiseNum = tempList[i].praiseNum + 1;
      flag = 1;
      wx.showToast({
        title: '点赞成功',
      });
    } else { //取消点赞
      tempList[i].praiseNum = tempList[i].praiseNum == 0 ? 0 : tempList[i].praiseNum - 1;
      flag = 0;
      wx.showToast({
        title: '已取消点赞',
      });
    }
    that.setData({
      [state]: !that.data.onLike[_id],
      uploadDocList: tempList
    });

    //修改云端数据
    that.upLoadLikeNumber(flag,_id,localopenid);
  },2000),

  //上传点赞数据
  upLoadLikeNumber : function (flag,id,opendId) {
    let operate  = null;
   operate = flag==1?'add':'remove';
    //事后上传数据
    //调用点赞数的云函数
    wx.cloud.callFunction({
      // 云函数名称
      name: 'upLoadOperate',
      // 传给云函数的参数
      data: {
        _id: id,
        flag:flag,
      },
      success: function (res) {
        wx.cloud.callFunction({
          // 调用获取指定数据的云函数
          name: 'praiseOperate',
          // 传递给云函数的event参数
          data: {
            recordId: id,
            clickUserId:opendId,
            operate:operate
          }
        }).then(res => {
          
        }).catch(err => {
        })
      },
      fail: console.error
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {


  }
})