var util = require('../../utils/util.js');

const app = getApp();

// pages/uploadphoto/uploadphoto.js
Page({
  data: {
    userInfo: {
      nickName: " 昵称 ",
      avatarUrl: "/images/user-unlogin.png"
    },
    imageUrl: "/images/placeHolderImg.png",
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    currentTime: "2019/07/10 21:00:00"
  },

  onLoad: function () {
    if (app.globalData.userInfo) {
      //全局应用已有用户信息 
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse) {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回 
      // 所以此处加入 callback 以防止这种情况 
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理 
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
    //获取当前时间，隔一秒刷新一次
    let that = this;
    showTime(that);
  },
  getUserInfo: function (e) {
    if (e.detail.errMsg != "getUserInfo:fail auth deny") {
      app.globalData.userInfo = e.detail.userInfo;
      this.setData({
        userInfo: e.detail.userInfo,
        hasUserInfo: true
      });
    }
  },

  chooseImages: function () {
    //回调函数里又有新的this对象，所以必须在外部保存this（即Page对象）引用
    let that = this;
    wx.chooseImage({
      count: 9,
      success: function (chooseRes) {
        //openId加生成唯一时间戳加图片索引作为图片的云路径前缀
        let openId = app.globalData.openId;
        //上传时间
        let time = new Date();
        let timeStamp = Date.parse(time).toString();
        //云路径前缀
        let imageCloudPathPrefix = 'CJRXHAlbum/' + openId + '/' + timeStamp + '/';
        //获取要上传多少张图片
        let length = chooseRes.tempFilePaths.length;
        //新建图片数组，存该次所上传的所有照片
        let imageUrls = new Array(length);
        wx.showLoading({
          title: '上传中, 请稍后',
        });
        //一张一张开始上传
        that.uploadImages(imageCloudPathPrefix, 0, chooseRes.tempFilePaths, length, time, imageUrls);
      },
      fail: function (res) {
        console.log("选择相片失败");
      }
    })
  },
  uploadImages: function (imageCloudPathPrefix, index, images, length, time, imageUrls) {
    let that = this;
    wx.cloud.uploadFile({
      cloudPath: imageCloudPathPrefix + index + '.png',
      filePath: images[index],
      success: function (res) {
        console.log("上传成功");
        //从上传结果中获取云端图片的路径url
        let imageUrl = res.fileID;
        //将图片url存入图片数组
        imageUrls[index] = imageUrl;
        console.log(imageUrls[index]);
        that.setData({
          imageUrl: imageUrl
        });
      },
      fail: function (res) {
        console.log("上传失败");
      },
      complete: function (res) {
        if ((index + 1) == length) {
          //如果是最后一张，将该次上传记录添加到数据库
          //头像
          let icon = that.data.userInfo.avatarUrl;
          //上传者昵称
          let name = that.data.userInfo.nickName;
          //将上传记录添加到云数据库
          that.addUploadDoc(icon, name, time, imageUrls);
        }
        else if (imageUrls[index] == null) {
          //失败，删回之前上传的照片
          for (let i = 0; i < imageUrls.length; i++) {
            let fileId = util.getFileId(imageUrls[i]);
            //从存储真正删除该图片
            wx.cloud.deleteFile({
              fileList: [fileId],
              success: function (res) {
                console.log("删除照片成功");
              },
              fail: function (res) {
                console.log("删除照片失败");
              }
            });
          }
          util.showTip('上传失败，请重试！');
          return;
        }
        else {
          //否则，传下一张
          index = index + 1;
          that.uploadImages(imageCloudPathPrefix, index, images, length, time, imageUrls);
        }
      }
    });
  },
  addUploadDoc: function (icon, name, time, imageUrls) {
    console.log(util.formatTime(time, "Y-M-D h:m:s"));
    //获得数据库引用
    const db = wx.cloud.database();
    //点赞数
    let praiseNum = 0;
    //把上传的图片添加到数据库
    db.collection("uploadDoc").add({
      data: {
        icon: icon,
        uploader: name,
        time: util.formatTime(time, "Y-M-D h:m:s"),
        imageUrls: imageUrls,
        praiseNum: praiseNum
      },
      success: function (res) {
        console.log("相片添加到数据库成功");
      },
      fail: function (res) {
        console.log("相片添加到数据库失败");
      },
      complete: function (res) {
        //上传完成
        wx.hideLoading();
        //跳转到记录显示页面
        wx.navigateTo({
          url: '../photolist/photolist',
        });
      }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  onShow: function () {

  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})

//获取当前时间，隔一秒刷新一次
function showTime(that) {
  that.setData({
    currentTime: util.formatTime(new Date(), "Y-M-D h:m:s")
  });
  setTimeout(function () {
    showTime(that);
  }, 1000);
}